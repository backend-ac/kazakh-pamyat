<?php $__env->startSection('content'); ?>
    <main>
        <section
            class="soldier"
            style="
        background: url('<?php echo e(optional($place)->banner
            ? asset('storage/' . $place->banner)
            : asset('img/soldier-1.jpg')); ?>') center/cover no-repeat
    "
        >
            <section class="breadcrumbs white">
                <div class="container">
                    <div class="breadcrumbs__container">
                        <ul class="breadcrumbs__list">
                            <li class="breadcrumbs__list-item">
                                <a href="/" class="breadcrumbs__list-link">Главная</a>
                            </li>
                            <li class="breadcrumbs__list-item">
                                <!-- Ссылка на место -->
                                <?php if($place): ?>
                                    <a href="<?php echo e(route('place.show', $place->id)); ?>" class="breadcrumbs__list-link">
                                        <?php echo e($place->title); ?>

                                    </a>
                                <?php endif; ?>
                            </li>
                            <li class="breadcrumbs__list-item">
                                <a href="#" class="breadcrumbs__list-link active">
                                    <?php echo e($participant->name); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </section>
            <h1 class="soldier__title title">
                <?php echo e($participant->name); ?>

            </h1>
        </section>
        <section class="bio">
            <div class="container">
                <div class="bio__container content">
                    <div class="bio__block">
                        <div class="bio__image">
                            <?php if($participant->photo): ?>
                                <img src="<?php echo e(asset('storage/' . $participant->photo)); ?>"
                                     alt="<?php echo e($participant->name); ?>"/>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/soldier-2.jpg')); ?>" alt="Заглушка"/>
                            <?php endif; ?>
                        </div>
                        <div class="bio__info">
                            <h2 class="bio__title title">БИОГРАФИЯ</h2>
                            <div class="bio__info-name"><?php echo e($participant->name); ?></div>
                            <div class="bio__info-list">
                                <li>Дата рождения: <?php echo e($participant->date_of_birth ?? 'Неизвестна'); ?></li>
                                <li>Причина выбытия: <?php echo e($participant->date_of_death ?? 'Неизвестна'); ?></li>
                                <!-- <li>Где
                                    воевал: <?php echo e($participant->where_did_participate ?? 'Информация уточняется.'); ?></li> -->
                            </div>
                            <!-- Если есть какое-то поле bio -->





                        </div>
                    </div>
                    <!-- Дополнительные блоки (infos), если есть -->
                    <?php if($participant->infos->count()): ?>
                        <?php $__currentLoopData = $participant->infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bio__block">
                                <div class="bio__image">
                                    <?php if($info->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $info->image)); ?>" alt="">
                                    <?php endif; ?>
                                    <?php if($info->image_description): ?>
                                        <span><?php echo e($info->image_description); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="bio__info">
                                    <div class="bio__info-text">
                                        <?php echo $info->text; ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="bio__more">
                        <span>Знаете больше? Отправьте нам информацию!</span>
                        <a href="/history">Отправить информацию</a>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/kazakh-pamyat.kz/httpdocs/resources/views/participant.blade.php ENDPATH**/ ?>