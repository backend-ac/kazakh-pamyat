<?php $__env->startSection('content'); ?>

    <main>
        <section class="breadcrumbs @class">
            <div class="container">
                <div class="breadcrumbs__container">
                    <ul class="breadcrumbs__list">
                        <li class="breadcrumbs__list-item">
                            <a href="/" class="breadcrumbs__list-link">Главная</a>
                        </li>
                        <li class="breadcrumbs__list-item">
                            <a href="#" class="breadcrumbs__list-link active"><?php echo e($place->title); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="about not-bg">
            <div class="container">
                <div class="about__container">
                    <div class="about__block">
                        <div class="about__block-img">
                            <?php if($place->place_image): ?>
                                <img src="<?php echo e(asset('storage/' . $place->place_image)); ?>" alt="<?php echo e($place->title); ?>"/>
                            <?php else: ?>
                                <img src="/img/about.jpg" alt="Заглушка"/>
                            <?php endif; ?>
                        </div>
                        <div class="about__block-info">
                            <h1 class="about__block-title title"> <?php echo e($place->title); ?></h1>
                            <div class="about__block-text">
                                <?php echo $place->text; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="search">
            <div class="container">
                <div class="search__container content">
                    <form action="<?php echo e(route('place.show', $place->id)); ?>" method="GET">
                        <div class="search__form">
                            <h2 class="search__form-title title">Поиск погибших</h2>
                            <div class="search__form-block">
                                <input
                                    type="text"
                                    name="q"
                                    class="search__form-input"
                                    placeholder="Поиск участники войны"
                                    value="<?php echo e(request('q')); ?>"
                                />
                                <button type="submit" class="search__form-submit">
                                   Поиск
                                </button>
                            </div>
                        </div>
                    </form>
                    <form action="" id="search-checkboxes">
                        <div class="search__checkboxes">
                            <label for="checkbox-1">
                                <input
                                    type="checkbox"
                                    id="checkbox-1"
                                    name="with_photo"
                                    value="1"
                                    <?php echo e(request('with_photo') ? 'checked' : ''); ?>

                                />
                                <span>Только с фото</span>
                            </label>
                            <label for="checkbox-2">
                                <input
                                    type="checkbox"
                                    id="checkbox-2"
                                    name="incomplete"
                                    value="1"
                                    <?php echo e(request('incomplete') ? 'checked' : ''); ?>

                                />
                                <span>С неполной информацией</span>
                            </label>
                        </div>
                    </form>
                    <div class="search__items">
                        <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card__item">
                                <?php if($participant->photo): ?>
                                    <div class="card__item-img">
                                        <img src="<?php echo e(asset('storage/' . $participant->photo)); ?>"
                                             alt="<?php echo e($participant->name); ?>"/>
                                    </div>
                                <?php else: ?>
                                    <div class="card__item-img">
                                        <img src="<?php echo e(asset('img/soldier-2.jpg')); ?>"
                                             alt="<?php echo e($participant->name); ?>"/>
                                    </div>

                                <?php endif; ?>


                                <div class="card__item-name"><?php echo e($participant->name); ?></div>

                                <ul class="card__item-list">
                                    <li>
                                        <span>Дата рождения:</span>
                                        <span><?php echo e($participant->date_of_birth ?? 'Неизвестна'); ?></span>
                                    </li>
                                    <li>
                                        <span>Причина выбытия:</span>
                                        <span><?php echo e($participant->date_of_death ?? 'Неизвестна'); ?></span>
                                    </li>




                                </ul>

                                <!-- Ссылка на детальную страницу участника (если уже есть маршрут 'participant.show') -->
                                <a href="<?php echo e(route('participant.show', $participant->id)); ?>" class="card__item-link">
                                    Подробнее
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <!-- Если нет участников -->
                            <div class="empty">
                                <div class="empty__image">
                                    <img src="/img/empty.png" alt=""/>
                                </div>

                            </div>
                        <?php endif; ?>
                    </div>
                    <?php echo e($participants->links('vendor.pagination.custom')); ?>


                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/kazakh-pamyat.kz/httpdocs/resources/views/place.blade.php ENDPATH**/ ?>