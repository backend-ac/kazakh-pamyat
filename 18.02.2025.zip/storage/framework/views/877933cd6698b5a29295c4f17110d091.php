<header class="header way way-header">
    <div class="header__top">
        <div class="container">
            <div class="header__container">
                <a href="/" class="header__logo">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" />
                </a>
                <nav class="header__nav">
                    <ul class="header__nav-list">
                        <li class="header__nav-item">
                            <a href="/" class="header__nav-link <?php echo e(request()->routeIs('index') ? 'active' : ''); ?>">Главная</a>
                        </li>
                        <li class="header__nav-item">
                            <a href="/about" class="header__nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">О проекте</a>
                        </li>
                        <li class="header__nav-item">
                            <a
                                href="javascript:;"
                                class="header__nav-link js-dropdown-btn"
                            >Участники войны</a
                            >
                        </li>
                        <li class="header__nav-item">
                            <a href="/history" class="header__nav-link <?php echo e(request()->routeIs('history') ? 'active' : ''); ?>">Ваши истории</a>
                        </li>
                    </ul>
                </nav>
                <div class="burger" id="menu-icon">
                    <div
                        class="burger__dot burger__dot--line burger__dot--left-top"
                    ></div>
                    <div class="burger__dot burger__dot--aside"></div>
                    <div
                        class="burger__dot burger__dot--line burger__dot--right-top"
                    ></div>
                    <div class="burger__dot burger__dot--aside"></div>
                    <div class="burger__dot burger__dot--aside"></div>
                    <div class="burger__dot burger__dot--aside"></div>
                    <div
                        class="burger__dot burger__dot--line burger__dot--left-bottom"
                    ></div>
                    <div class="burger__dot burger__dot--aside"></div>
                    <div
                        class="burger__dot burger__dot--line burger__dot--right-bottom"
                    ></div>
                </div>
            </div>
        </div>

        <div class="header__dropdown">
            <div class="container">
                <div class="header__dropdown-block">
                    <div class="header__dropdown-list">
                        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a
                                href="javascript:;"
                                data-id="<?php echo e($place->id); ?>"
                                class="header__dropdown-village <?php if($loop->first): ?> active <?php endif; ?>"
                            >
                                <?php echo e($place->title); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="header__dropdown-heroes">
                        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $place->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a
                                    href="<?php echo e(route('participant.show', $participant->id)); ?>"
                                    data-id="<?php echo e($place->id); ?>"
                                    class="header__dropdown-name <?php if($loop->parent->first): ?> active <?php endif; ?>"
                                >
                                    <?php echo e($participant->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header__bot">
        <div class="container">
            <div class="header__villages">
                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('place.show', $place->id)); ?>">
                        <?php echo e($place->title); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</header>
<div class="header-space"></div>
<?php /**PATH /var/www/vhosts/kazakh-pamyat.kz/httpdocs/resources/views/layouts/header.blade.php ENDPATH**/ ?>