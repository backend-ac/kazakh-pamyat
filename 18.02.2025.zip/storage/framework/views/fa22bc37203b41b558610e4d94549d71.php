<?php $__env->startSection('meta'); ?>
    <title><?php echo e($page->meta_title ?? 'Память в обелиске'); ?></title>
    <meta name="description" content="<?php echo e($page->meta_description ?? ''); ?>">
    <meta name="keywords" content="<?php echo e($page->meta_keywords ?? ''); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="hero">
            <div class="hero__slider swiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide hero__slide">
                            <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="Banner"/>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="container">
                <div class="hero__container">
                    <a href="javascript:;" class="hero__arrow prev">
                        <svg
                            width="52"
                            height="52"
                            viewBox="0 0 52 52"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M26 1C34.9316 1 43.1848 5.76497 47.6506 13.5C52.1165 21.235 52.1165 30.765 47.6506 38.5C43.1848 46.235 34.9316 51 26 51C12.1929 51 1 39.8071 1 26C1 12.1929 12.1929 1 26 1"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M15 26L26 15"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M15.6252 26H37"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M26 37L15 26"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </a>
                    <a href="javascript:;" class="hero__arrow next">
                        <svg
                            width="52"
                            height="52"
                            viewBox="0 0 52 52"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M26 1C17.0684 1 8.81518 5.76497 4.34936 13.5C-0.116455 21.235 -0.116455 30.765 4.34936 38.5C8.81518 46.235 17.0684 51 26 51C39.8071 51 51 39.8071 51 26C51 12.1929 39.8071 1 26 1"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M37 26L26 15"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M36.3748 26H15"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <path
                                d="M26 37L37 26"
                                stroke="white"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </a>
                </div>
            </div>
        </section>


        <section class="preview">
            <div class="container">
                <div class="preview__container content">
                    <h2 class="preview__title title"><?php echo e($page->components[0]->title); ?></h2>
                    <div class="preview__text">
                        <?php echo $page->components[0]->description; ?>

                    </div>
                </div>
            </div>
            <div class="preview__images">
                <?php $__currentLoopData = $main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="preview__image">
                        <img src="<?php echo e(asset('storage/' . $image -> photo)); ?>" alt="<?php echo e($image -> name); ?>"/>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </section>
        <section class="dead">
            <div class="container">
                <div class="dead__container content">
                    <h2 class="dead__title title">Поиск погибших</h2>
                    <div class="dead__items">
                        <?php
                            // Возьмём первые 9 (на случай, если в `$main` больше
                            $participants = $main->take(9);
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div class="dead__item <?php if($index >= 3): ?> hidden <?php endif; ?>">
                                <div class="dead__item-img">
                                    
                                    <img
                                        src="<?php echo e($participant->photo
                                    ? asset('storage/'.$participant->photo)
                                    : asset('img/soldier-2.jpg')); ?>"
                                        alt="<?php echo e($participant->name); ?>"
                                    />
                                </div>

                                <div class="dead__item-name">
                                    <?php echo e($participant->name); ?>

                                </div>

                                <div class="dead__item-date">
                                    <?php echo e($participant->date_of_birth ?? 'Неизвестно'); ?>

                                    -
                                    <?php echo e($participant->date_of_death ?? 'Неизвестно'); ?>

                                </div>

                                <div class="dead__item-place">
                                    <?php echo e($participant->where_did_participate ?? 'Информация уточняется'); ?>

                                </div>

                                <a
                                    href="<?php echo e(route('participant.show', $participant->id)); ?>"
                                    class="dead__item-link"
                                >
                                    Подробнее
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="dead__item">
                                <div class="dead__item-name">
                                    Нет участников
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="dead__more-wrapper">
                        <a href="javascript:;" class="dead__more">
                            <span> Показать все </span>
                            <span> Скрыть </span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="gallery">
            <div class="gallery__container content">
                <h2 class="gallery__title title">Галерея памятных фотографий</h2>
                <div class="gallery__ticker ticker-1" data-duplicated="true">
                    <?php $__currentLoopData = $topImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img
                            src="<?php echo e(asset('storage/'.$image->image)); ?>"
                            alt=""
                            data-fancybox
                            data-src="<?php echo e(asset('storage/'.$image->image)); ?>"
                        />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="gallery__ticker ticker-2" data-duplicated="true">
                    <?php $__currentLoopData = $bottomImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img
                            src="<?php echo e(asset('storage/'.$image->image)); ?>"
                            alt=""
                            data-fancybox
                            data-src="<?php echo e(asset('storage/'.$image->image)); ?>"
                        />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <?php if (isset($component)) { $__componentOriginalea0251fb1a0c347c5b9734186cb59bad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea0251fb1a0c347c5b9734186cb59bad = $attributes; } ?>
<?php $component = App\View\Components\FeedbackForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feedback-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FeedbackForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea0251fb1a0c347c5b9734186cb59bad)): ?>
<?php $attributes = $__attributesOriginalea0251fb1a0c347c5b9734186cb59bad; ?>
<?php unset($__attributesOriginalea0251fb1a0c347c5b9734186cb59bad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea0251fb1a0c347c5b9734186cb59bad)): ?>
<?php $component = $__componentOriginalea0251fb1a0c347c5b9734186cb59bad; ?>
<?php unset($__componentOriginalea0251fb1a0c347c5b9734186cb59bad); ?>
<?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/kazakh-pamyat.kz/httpdocs/resources/views/home.blade.php ENDPATH**/ ?>